//
//  Page.swift
//  tygate
//
//  Created by ashwin challa on 1/21/19.
//  Copyright © 2019 Bharat shankar. All rights reserved.
//

import UIKit

class Page: UIView {

    @IBOutlet weak var pageImage: UIImageView!
    

}
