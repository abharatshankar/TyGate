//
//  educationTableViewCell.swift
//  tygate
//
//  Created by Bharat shankar on 29/01/19.
//  Copyright © 2019 Bharat shankar. All rights reserved.
//

import UIKit

class educationTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
