//
//  URLS.swift
//  Touchless
//
//  Created by Martijn De Bruijn on 06-11-17.
//  Copyright © 2017 Inventief-it. All rights reserved.
//

let API_ROOT = "http://testingmadesimple.org/hydmarket/api/services/";



let API_SIGNUP_DEVICE = API_ROOT + "signup";

//forgot in hyd market
let API_FORGOT_PASSWORD = API_ROOT + "forgotPassword";

let API_VERIFY_OTP = API_ROOT + "verifyOtp";

let API_AROUND_ME_CATEGORIES_SERVICE = API_ROOT + "categorystores";


let API_LOGIN_DEVICE = API_ROOT + "login";




let API_RESEND_OTP = API_ROOT + "resendotp";



let API_PROFILE = API_ROOT + "profile";

let API_EDIT_PROFILE = API_ROOT + "editprofile";

let API_CHANGE_PASSWORD = API_ROOT + "changepassword";

let API_USER_BOXES = API_ROOT + "userboxes";

let API_ADD_ACCESS = API_ROOT + "addaccess";

let API_ACCESS_LIST = API_ROOT + "accesslist";

let API_ACCESS_INFO = API_ROOT + "accessinfo";

let API_EDIT_ACCESS = API_ROOT + "editaccess";

let API_DELETE_ACCESS = API_ROOT + "deleteaccess";

