//
//  NotificationNames.swift
//  Touchless
//
//  Created by Martijn De Bruijn on 06-11-17.
//  Copyright © 2017 Inventief-it. All rights reserved.
//

import Foundation 

//sign up
let CREATE_ACCOUNT_WITH_DEVICE_NOTIFICATION = NSNotification.Name("create_account_with_device_notification")

let AROUND_ME_CATEGORIES = NSNotification.Name("Around_me_categories_NOTIFICATION")


let LOG_IN_WITH_DEVICE_NOTIFICATION = NSNotification.Name("log_in_with_device_notification")

let VERIFY_OTP_WITH_DEVICE_NOTIFICATION  = NSNotification.Name ("verify_otp_with_device_notification")

let RESEND_OTP_WITH_DEVICE_NOTIFICATION = NSNotification.Name ("resend_otp_with_device_notification")

//forgot in hyd market
let FORGOT_PASSWORD_WITH_DEVICE_NOTIFICATION = NSNotification.Name ("forgot_password_with_device_notification")

let PROFILE_WITH_DEVICE_NOTIFICATION = NSNotification.Name ("profile_with_device_notification")

let EDIT_PROFILE_WITH_DEVICE_NOTIFICATION = NSNotification.Name ("edit_profile_with_device_notification")

let CHANGE_PASSWORD_WITH_DEVICE_NOTIFICATION = NSNotification.Name ("change_password_with_device_notification")






