//
//  JobDetailsVC.swift
//  tygate
//
//  Created by Dr Mohan Roop on 1/24/19.
//  Copyright © 2019 Bharat shankar. All rights reserved.
//

import UIKit

class JobDetailsVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

  

}
